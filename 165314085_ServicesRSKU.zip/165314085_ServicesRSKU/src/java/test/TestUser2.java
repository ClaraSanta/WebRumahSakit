/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import com.google.gson.Gson;
import helper.UserHelper;
import java.util.List;
import pojos.User;

/**
 *
 * @author Windows
 */
public class TestUser2 {

//    public static void main(String[] args) {
//        UserHelper U = new UserHelper();
//        User user = U.getUser("123456789", "puspa@usd.ac.id");
//        if (user != null) {
//            Gson gson = new Gson();
//            String json = gson.toJson(user);
//            System.out.println(json);
//        }
//        
//        User user2 = U.getUser("1234", "puspa@usd.ac.id");
//        if (user2 != null) {
//            Gson gson = new Gson();
//            String json = gson.toJson(user2);
//            System.out.println(json);
//        }
//        
//        User user3 = U.getUser("1234567", "puspa@usd.ac.id");
//        if (user2 != null) {
//            Gson gson = new Gson();
//            String json = gson.toJson(user3);
//            System.out.println(json);
//        }
//    }
}
